
@tool
extends EditorPlugin

var panel: VBoxContainer
var color_btn: ColorPickerButton
var chosen_color: Color = Color(0.25, 0.7, 1.0, 1.0)
var stable_by_asset: bool = true
var roughness_value: float = 0.9
var metallic_value: float = 0.0

# UI rows
var pattern_row: HBoxContainer
var rough_row: HBoxContainer
var metal_row: HBoxContainer
var rough_spin: SpinBox
var metal_spin: SpinBox
var defaults_row: HBoxContainer

# Default quick colors
var default_colors: Array = [
    Color8(231,76,60),   # red
    Color8(230,126,34),  # orange
    Color8(241,196,15),  # yellow
    Color8(46,204,113),  # green
    Color8(26,188,156),  # teal
    Color8(52,152,219),  # blue
    Color8(142,68,173),  # purple
    Color8(236,112,99),  # salmon
    Color8(165,105,189), # violet
    Color8(127,140,141)  # gray
]

# Pattern types
const PATTERN_NONE := 0 # no texture
const PATTERN_DOTS := 1
const PATTERN_NOISE := 2
const PATTERN_CROSSHATCH := 3
var pattern_type: int = PATTERN_NONE
var detail_tex: Texture2D

func _enter_tree() -> void:
    _rebuild_detail_texture()
    _build_panel()
    panel.name = "Recolorizer"
    # Dockable / floatable panel
    add_control_to_dock(DOCK_SLOT_RIGHT_UL, panel)

    add_tool_menu_item("colorize all", Callable(self, "_colorize_all"))
    add_tool_menu_item("Clear (All)", Callable(self, "_clear_all"))
    add_tool_menu_item("Colorize Selection", Callable(self, "_colorize_selection"))
    add_tool_menu_item("Apply Texture (Selection)", Callable(self, "_apply_texture_selection"))
    add_tool_menu_item("Apply Roughness (Selection)", Callable(self, "_apply_roughness_selection"))
    add_tool_menu_item("Apply Metalness (Selection)", Callable(self, "_apply_metalness_selection"))
    add_tool_menu_item("Clear Selection", Callable(self, "_clear_selection"))
    add_tool_menu_item("Focus Recolorizer", Callable(self, "_show_panel"))

func _exit_tree() -> void:
    remove_tool_menu_item("colorize all")
    remove_tool_menu_item("Clear (All)")
    remove_tool_menu_item("Colorize Selection")
    remove_tool_menu_item("Apply Texture (Selection)")
    remove_tool_menu_item("Apply Roughness (Selection)")
    remove_tool_menu_item("Apply Metalness (Selection)")
    remove_tool_menu_item("Clear Selection")
    remove_tool_menu_item("Focus Recolorizer")
    if is_instance_valid(panel):
        remove_control_from_docks(panel)
        panel.queue_free()

func _show_panel() -> void:
    if is_instance_valid(panel):
        panel.visible = true
        panel.grab_focus()

func _build_panel() -> void:
    panel = VBoxContainer.new()
    panel.custom_minimum_size = Vector2(560, 0)

    var title = Label.new()
    title.text = "Recolorizer"
    title.add_theme_font_size_override("font_size", 14)
    panel.add_child(title)

    # Color picker row
    var row1 = HBoxContainer.new()
    var lbl = Label.new()
    lbl.text = "Color:"
    lbl.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
    row1.add_child(lbl)

    color_btn = ColorPickerButton.new()
    color_btn.color = chosen_color
    color_btn.edit_alpha = true
    color_btn.custom_minimum_size = Vector2(340, 0) # wider
    color_btn.color_changed.connect(_on_color_changed_live)
    row1.add_child(color_btn)

    var stable_cb = CheckButton.new()
    stable_cb.text = "Same color per asset"
    stable_cb.button_pressed = stable_by_asset
    stable_cb.toggled.connect(_on_stable_toggled)
    row1.add_child(stable_cb)

    panel.add_child(row1)

    # Default colors quick row
    var d_lbl = Label.new()
    d_lbl.text = "Defaults:"
    panel.add_child(d_lbl)
    defaults_row = HBoxContainer.new()
    defaults_row.add_theme_constant_override("separation", 6)
    panel.add_child(defaults_row)
    _rebuild_defaults_row()

    # Also seed picker presets with defaults
    var picker := color_btn.get_picker()
    if picker:
        for c in default_colors:
            if picker.has_method("add_preset"):
                picker.add_preset(c)

    panel.add_child(HSeparator.new())

    # Pattern row
    pattern_row = HBoxContainer.new()
    var p_lbl = Label.new()
    p_lbl.text = "Texture:"
    pattern_row.add_child(p_lbl)

    var btn_none = _make_pattern_button("none", PATTERN_NONE)
    pattern_row.add_child(btn_none)
    var btn_dots = _make_pattern_button("dots", PATTERN_DOTS)
    pattern_row.add_child(btn_dots)
    var btn_noise = _make_pattern_button("noise", PATTERN_NOISE)
    pattern_row.add_child(btn_noise)
    var btn_cross = _make_pattern_button("cross-hatch", PATTERN_CROSSHATCH)
    pattern_row.add_child(btn_cross)

    panel.add_child(pattern_row)

    # Roughness row
    rough_row = HBoxContainer.new()
    var r_lbl = Label.new()
    r_lbl.text = "Roughness:"
    rough_row.add_child(r_lbl)
    rough_spin = SpinBox.new()
    rough_spin.min_value = 0.0
    rough_spin.max_value = 1.0
    rough_spin.step = 0.01
    rough_spin.value = roughness_value
    rough_spin.value_changed.connect(_on_roughness_changed)
    rough_row.add_child(rough_spin)

    var btn_apply_rough = Button.new()
    btn_apply_rough.text = "Apply Roughness (Selection)"
    btn_apply_rough.pressed.connect(_apply_roughness_selection)
    rough_row.add_child(btn_apply_rough)

    panel.add_child(rough_row)

    # Metalness row
    metal_row = HBoxContainer.new()
    var m_lbl = Label.new()
    m_lbl.text = "Metalness:"
    metal_row.add_child(m_lbl)
    metal_spin = SpinBox.new()
    metal_spin.min_value = 0.0
    metal_spin.max_value = 1.0
    metal_spin.step = 0.01
    metal_spin.value = metallic_value
    metal_spin.value_changed.connect(_on_metalness_changed_local)
    metal_row.add_child(metal_spin)

    var btn_apply_metal = Button.new()
    btn_apply_metal.text = "Apply Metalness (Selection)"
    btn_apply_metal.pressed.connect(_apply_metalness_selection)
    metal_row.add_child(btn_apply_metal)

    panel.add_child(metal_row)

    panel.add_child(HSeparator.new())

    # Actions
    var actions1 = HBoxContainer.new()
    var btn_colorize_all = Button.new()
    btn_colorize_all.text = "colorize all"
    btn_colorize_all.pressed.connect(_colorize_all)
    actions1.add_child(btn_colorize_all)

    var btn_clear_all = Button.new()
    btn_clear_all.text = "Clear All"
    btn_clear_all.pressed.connect(_clear_all)
    actions1.add_child(btn_clear_all)

    panel.add_child(actions1)

    var actions2 = HBoxContainer.new()
    var btn_colorize_sel = Button.new()
    btn_colorize_sel.text = "Colorize Selection"
    btn_colorize_sel.pressed.connect(_colorize_selection)
    actions2.add_child(btn_colorize_sel)

    var btn_apply_tex_sel = Button.new()
    btn_apply_tex_sel.text = "Apply Texture (Selection)"
    btn_apply_tex_sel.pressed.connect(_apply_texture_selection)
    actions2.add_child(btn_apply_tex_sel)

    var btn_clear_sel = Button.new()
    btn_clear_sel.text = "Clear Selection"
    btn_clear_sel.pressed.connect(_clear_selection)
    actions2.add_child(btn_clear_sel)

    panel.add_child(actions2)

# --- UI builders ---
func _make_pattern_button(label_text: String, p_type: int) -> Button:
    var b := Button.new()
    b.text = label_text
    b.toggle_mode = true
    b.button_pressed = (p_type == pattern_type)
    b.pressed.connect(Callable(self, "_on_pattern_pressed").bind(p_type, b))
    return b

func _on_pattern_pressed(p_type: int, btn: Button) -> void:
    pattern_type = p_type
    for child in pattern_row.get_children().duplicate():
        if child is Button and child != btn:
            child.button_pressed = false
    btn.button_pressed = true
    _rebuild_detail_texture()

func _rebuild_defaults_row() -> void:
    for c in defaults_row.get_children().duplicate():
        defaults_row.remove_child(c)
        c.queue_free()
    for col in default_colors:
        var b = _make_color_square_button(col)
        defaults_row.add_child(b)

func _make_color_square_button(col: Color) -> Button:
    var b := Button.new()
    b.toggle_mode = false
    b.flat = false
    b.custom_minimum_size = Vector2(28, 28)
    b.icon = _make_swatch_icon(col)
    b.focus_mode = Control.FOCUS_NONE
    b.tooltip_text = "R:%.0f G:%.0f B:%.0f" % [col.r*255.0, col.g*255.0, col.b*255.0]
    b.set_meta("swatch_color", col)
    b.pressed.connect(Callable(self, "_on_default_color_pressed").bind(b))
    return b

func _make_swatch_icon(col: Color) -> Texture2D:
    var sz := 24
    var img := Image.create(sz, sz, false, Image.FORMAT_RGBA8)
    for y in range(sz):
        for x in range(sz):
            var border := (x == 0) or (y == 0) or (x == sz-1) or (y == sz-1)
            var c: Color = col
            if border:
                c = Color(0,0,0,1)
            img.set_pixel(x, y, c)
    return ImageTexture.create_from_image(img)

# --- Handlers ---
func _on_default_color_pressed(btn: Button) -> void:
    var col: Color = btn.get_meta("swatch_color")
    color_btn.color = col # update picker
    # Immediately colorize current selection
    var sel = get_editor_interface().get_selection()
    if sel != null:
        var nodes = sel.get_selected_nodes()
        for n in nodes:
            _apply_recursive_with_color(n, col)

func _on_color_changed_live(c: Color) -> void:
    chosen_color = c
    # live preview on current selection
    var sel = get_editor_interface().get_selection()
    if sel != null:
        var nodes = sel.get_selected_nodes()
        for n in nodes:
            _apply_recursive_with_color(n, c)

func _on_stable_toggled(v: bool) -> void:
    stable_by_asset = v

func _on_roughness_changed(v: float) -> void:
    roughness_value = clamp(v, 0.0, 1.0)
    # Live-update selection with new roughness, preserving color
    var sel = get_editor_interface().get_selection()
    if sel != null:
        var nodes = sel.get_selected_nodes()
        for n in nodes:
            var col := _get_current_color_or_default(n, chosen_color)
            _apply_recursive_with_color(n, col)

func _on_metalness_changed_local(v: float) -> void:
    metallic_value = clamp(v, 0.0, 1.0)
    # explicit apply via button

# ---- Pattern textures ----
func _rebuild_detail_texture() -> void:
    match pattern_type:
        PATTERN_NONE:
            detail_tex = null # no texture
        PATTERN_DOTS:
            detail_tex = _make_dots_texture()
        PATTERN_NOISE:
            detail_tex = _make_noise_texture()
        PATTERN_CROSSHATCH:
            detail_tex = _make_crosshatch_texture()

func _make_dots_texture() -> Texture2D:
    var size := 128
    var spacing := 10
    var radius := 2.5
    var img := Image.create(size, size, false, Image.FORMAT_RGBA8)
    img.fill(Color(0.97, 0.97, 0.97, 1.0))
    for y in range(0, size, spacing):
        for x in range(0, size, spacing):
            for yy in range(-int(radius*2), int(radius*2)+1):
                for xx in range(-int(radius*2), int(radius*2)+1):
                    var px := (x + xx + size) % size
                    var py := (y + yy + size) % size
                    var d := sqrt(float(xx*xx + yy*yy))
                    if d <= radius:
                        img.set_pixel(px, py, Color(0.85, 0.85, 0.85, 1.0))
    return ImageTexture.create_from_image(img)

func _make_noise_texture() -> Texture2D:
    var size := 128
    var img := Image.create(size, size, false, Image.FORMAT_RGBA8)
    var rng := RandomNumberGenerator.new()
    rng.seed = 987654321 # stable noise
    for y in range(size):
        for x in range(size):
            var v := 0.85 + rng.randf() * 0.12 # 0.85..0.97 stronger variance
            img.set_pixel(x, y, Color(v, v, v, 1.0))
    return ImageTexture.create_from_image(img)

func _make_crosshatch_texture() -> Texture2D:
    var size := 128
    var period := 9
    var thickness := 2
    var img := Image.create(size, size, false, Image.FORMAT_RGBA8)
    img.fill(Color(0.96, 0.96, 0.96, 1.0))
    for y in range(size):
        for x in range(size):
            var draw := ((x + y) % period < thickness) or (((x - y) % period + period) % period < thickness)
            var v := 0.86 if draw else 0.96
            img.set_pixel(x, y, Color(v, v, v, 1.0))
    return ImageTexture.create_from_image(img)

# ---- Core ops ----

func _colorize_all() -> void:
    var root = get_editor_interface().get_edited_scene_root()
    if root == null:
        return

    if stable_by_asset:
        var groups: Dictionary = {} # key -> Array[Node]
        _gather_groups_by_asset(root, groups)
        var keys: Array = groups.keys()
        keys.sort()

        var total := keys.size()
        for i in range(total):
            var key: String = keys[i]
            var col := _distinct_color(i, total)
            for n in groups[key]:
                _apply_node_with_color(n, col)
    else:
        var nodes: Array = []
        _gather_all_mesh_nodes(root, nodes)
        var totaln := nodes.size()
        for i in range(totaln):
            var col := _distinct_color(i, totaln)
            _apply_node_with_color(nodes[i], col)

func _gather_groups_by_asset(n: Node, groups: Dictionary) -> void:
    if (n is MeshInstance3D) or (n is MultiMeshInstance3D):
        var key := _asset_key_for_node(n)
        if not groups.has(key):
            groups[key] = []
        groups[key].append(n)
    for c in n.get_children():
        _gather_groups_by_asset(c, groups)

func _gather_all_mesh_nodes(n: Node, out: Array) -> void:
    if (n is MeshInstance3D) or (n is MultiMeshInstance3D):
        out.append(n)
    for c in n.get_children():
        _gather_all_mesh_nodes(c, out)

func _asset_key_for_node(n: Node) -> String:
    # Prefer instanced scene file path
    if n.has_method("get_scene_file_path"):
        var p = n.get_scene_file_path()
        if typeof(p) == TYPE_STRING and p != "":
            return p
    # Fallback: mesh resource path
    if n is MeshInstance3D and n.mesh != null:
        if String(n.mesh.resource_path) != "":
            return String(n.mesh.resource_path)
    # Last resort: class + name
    return str(n.get_class(), ":", n.name)

func _distinct_color(i: int, total: int) -> Color:
    # Golden angle hue spacing
    var hue := fmod((i * 0.61803398875), 1.0)
    var sat := 0.75
    var val := 0.95
    return Color.from_hsv(hue, sat, val, 1.0)

func _colorize_selection() -> void:
    var sel = get_editor_interface().get_selection()
    if sel == null:
        return
    var nodes = sel.get_selected_nodes()
    for n in nodes:
        _apply_recursive_with_color(n, chosen_color)

func _apply_texture_selection() -> void:
    # Apply current texture & keep existing color; also update roughness/metalness
    var sel = get_editor_interface().get_selection()
    if sel == null:
        return
    var nodes = sel.get_selected_nodes()
    for n in nodes:
        _apply_texture_only_recursive(n)

func _apply_roughness_selection() -> void:
    var sel = get_editor_interface().get_selection()
    if sel == null:
        return
    var nodes = sel.get_selected_nodes()
    for n in nodes:
        _apply_roughness_only_recursive(n)

func _apply_metalness_selection() -> void:
    var sel = get_editor_interface().get_selection()
    if sel == null:
        return
    var nodes = sel.get_selected_nodes()
    for n in nodes:
        _apply_metalness_only_recursive(n)

func _get_current_color_or_default(n: Node, fallback: Color) -> Color:
    if n is MeshInstance3D and n.material_override is StandardMaterial3D:
        return (n.material_override as StandardMaterial3D).albedo_color
    if n is MultiMeshInstance3D and n.material is StandardMaterial3D:
        return (n.material as StandardMaterial3D).albedo_color
    return fallback

func _apply_recursive_with_color(n: Node, col: Color) -> void:
    if n is MeshInstance3D:
        _apply_mesh_with_color(n, col)
    elif n is MultiMeshInstance3D:
        _apply_multimesh_with_color(n, col)
    for c in n.get_children():
        _apply_recursive_with_color(c, col)

func _apply_texture_only_recursive(n: Node) -> void:
    if n is MeshInstance3D:
        var mi := n as MeshInstance3D
        if mi.material_override is StandardMaterial3D:
            var mat := (mi.material_override as StandardMaterial3D).duplicate()
            # Preserve color; only apply texture + params
            mat.albedo_texture = detail_tex
            mat.uv1_triplanar = detail_tex != null
            if detail_tex != null:
                mat.uv1_scale = Vector3(0.5, 0.5, 0.5)
            mat.roughness = roughness_value
            mat.metallic = metallic_value
            mi.material_override = mat
            mi.set_meta("rcp_applied", true)
    elif n is MultiMeshInstance3D:
        var mmi := n as MultiMeshInstance3D
        if mmi.material is StandardMaterial3D:
            var mat2 := (mmi.material as StandardMaterial3D).duplicate()
            mat2.albedo_texture = detail_tex
            mat2.uv1_triplanar = detail_tex != null
            if detail_tex != null:
                mat2.uv1_scale = Vector3(0.5, 0.5, 0.5)
            mat2.roughness = roughness_value
            mat2.metallic = metallic_value
            mmi.material = mat2
            mmi.set_meta("rcp_applied", true)
    for c in n.get_children():
        _apply_texture_only_recursive(c)

func _apply_roughness_only_recursive(n: Node) -> void:
    if n is MeshInstance3D:
        var mi := n as MeshInstance3D
        if mi.material_override is StandardMaterial3D:
            var mat := (mi.material_override as StandardMaterial3D).duplicate()
            mat.roughness = roughness_value
            mi.material_override = mat
            mi.set_meta("rcp_applied", true)
    elif n is MultiMeshInstance3D:
        var mmi := n as MultiMeshInstance3D
        if mmi.material is StandardMaterial3D:
            var mat2 := (mmi.material as StandardMaterial3D).duplicate()
            mat2.roughness = roughness_value
            mmi.material = mat2
            mmi.set_meta("rcp_applied", true)
    for c in n.get_children():
        _apply_roughness_only_recursive(c)

func _apply_metalness_only_recursive(n: Node) -> void:
    if n is MeshInstance3D:
        var mi := n as MeshInstance3D
        if mi.material_override is StandardMaterial3D:
            var mat := (mi.material_override as StandardMaterial3D).duplicate()
            mat.metallic = metallic_value
            mi.material_override = mat
            mi.set_meta("rcp_applied", true)
    elif n is MultiMeshInstance3D:
        var mmi := n as MultiMeshInstance3D
        if mmi.material is StandardMaterial3D:
            var mat2 := (mmi.material as StandardMaterial3D).duplicate()
            mat2.metallic = metallic_value
            mmi.material = mat2
            mmi.set_meta("rcp_applied", true)
    for c in n.get_children():
        _apply_metalness_only_recursive(c)

func _clear_selection() -> void:
    var sel = get_editor_interface().get_selection()
    if sel == null:
        return
    var nodes = sel.get_selected_nodes()
    for n in nodes:
        _clear_recursive(n)

func _clear_all() -> void:
    var root = get_editor_interface().get_edited_scene_root()
    if root == null:
        return
    _clear_recursive(root)

func _clear_recursive(n: Node) -> void:
    if (n is MeshInstance3D) and n.has_meta("rcp_applied"):
        n.material_override = n.get_meta("rcp_prev_override")
        n.remove_meta("rcp_prev_override")
        n.remove_meta("rcp_applied")
    elif (n is MultiMeshInstance3D) and n.has_meta("rcp_applied"):
        n.material = n.get_meta("rcp_prev_material")
        n.remove_meta("rcp_prev_material")
        n.remove_meta("rcp_applied")
    for c in n.get_children():
        _clear_recursive(c)

func _new_material(col: Color) -> StandardMaterial3D:
    var mat := StandardMaterial3D.new()
    mat.metallic = metallic_value
    mat.roughness = roughness_value
    mat.albedo_color = col
    if detail_tex:
        mat.albedo_texture = detail_tex
        mat.uv1_triplanar = true
        mat.uv1_scale = Vector3(0.5, 0.5, 0.5)
    else:
        mat.albedo_texture = null
        mat.uv1_triplanar = false
    return mat

func _apply_node_with_color(n: Node, col: Color) -> void:
    if n is MeshInstance3D:
        _apply_mesh_with_color(n, col)
    elif n is MultiMeshInstance3D:
        _apply_multimesh_with_color(n, col)

func _apply_mesh_with_color(mi: MeshInstance3D, col: Color) -> void:
    if not mi.has_meta("rcp_applied"):
        mi.set_meta("rcp_prev_override", mi.material_override)
    mi.material_override = _new_material(col)
    mi.set_meta("rcp_applied", true)

func _apply_multimesh_with_color(mmi: MultiMeshInstance3D, col: Color) -> void:
    if not mmi.has_meta("rcp_applied"):
        mmi.set_meta("rcp_prev_material", mmi.material)
    mmi.material = _new_material(col)
    mmi.set_meta("rcp_applied", true)
